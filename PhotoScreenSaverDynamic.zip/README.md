# PhotoScreenDirectParam.bat

Un script batch pour Windows 11 permettant de **changer dynamiquement le dossier utilisé par le screensaver PhotoScreenSaver**.

## 🚀 Fonctionnalités
- Définit le dossier source à utiliser pour l'affichage des photos.
- Crée un **lien symbolique** vers le dossier voulu.
- Supprime automatiquement l’ancien dossier/lien.
- Vérifie la présence des paramètres et affiche une erreur claire avec `PAUSE` en cas d’oubli.
- (Optionnel) Lance directement le screensaver `PhotoScreenSaver.scr`.

## 🛠️ Utilisation

### Syntaxe
```bat
PhotoScreenDirectParam.bat "DossierSource" "DossierStandard" "FichierLog" [Launch]
```

### Paramètres
- `DossierSource` : dossier contenant les photos à afficher.
- `DossierStandard` : dossier utilisé par PhotoScreenSaver (sera remplacé par un lien symbolique).
- `FichierLog` : chemin vers le fichier de log.
- `Launch` *(optionnel)* : si présent, lance immédiatement le screensaver.

### Exemple
```bat
cd D:\Users\Prénom\Documents\PhotoScreenSaver\
PhotoScreenDirectParam.bat ^
  "D:\Users\Prenom\Photos\CameraDV\a98_03_Paris" ^
  "D:\Users\Prenom\Photos\PhotoScreenFolder" ^
  "D:\DirectParam.LOG" ^
  Launch
```

---

## ⚠️ Pré-requis
- **Droits administrateur** : nécessaires pour créer un lien symbolique (`mklink`).
- Windows 11 avec `PhotoScreensaver.scr` installé (généralement dans `C:\Windows\System32`).

---

## 📌 Notes
- Le script supprime le dossier cible (`DossierStandard`) avant de créer le lien symbolique.
- Les erreurs de paramètres s’affichent avec un `PAUSE` → utile pour exécuter le script en double-clic.
- Les logs sont enregistrés avec horodatage dans le fichier défini par `FichierLog`.

---

## ✨ Améliorations possibles
- Version PowerShell avec meilleure gestion des erreurs.
- Détection automatique de `PhotoScreensaver.scr`.
- Ajout d’une interface graphique minimale.

---

## 📜 Licence
Distribué sous licence **GNU GPL v3**.  
Cela signifie que vous pouvez utiliser, modifier et partager ce script librement,  
mais **toute redistribution doit se faire sous la même licence**.  

👉 En clair : vous ne pouvez pas prendre ce script et en faire un logiciel propriétaire ou commercial fermé.

Voir le fichier LICENSE pour les détails complets.
